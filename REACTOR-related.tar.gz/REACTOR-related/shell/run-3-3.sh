#!/bin/bash

source ~/work/my_setup.sh
#export ATMPD_ROOT=
#export SKOFL_ROOT=
#export LD_LIBRARY_PATH=/home/guang/work/geant4.10.04.p02/builddir/BuildProducts/lib:/home/guang/Downloads/root-6.14.02/builddir/lib:/home/guang/work/geant4.10.04.p02/builddir/BuildProducts/lib:/home/guang/work/geant4.10.04.p02/builddir/BuildProducts/lib:/home/guang/work/geant4.10.04.p02/builddir/BuildProducts/lib:/home/guang/Downloads/root-6.14.02/builddir/lib

#source /disk01/usr5/gyang/REACTOR-related/makeApp
#/disk01/usr5/gyang/REACTOR-related/app 3 3
./app 3 3

